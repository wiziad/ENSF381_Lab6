import React from 'react';
import './App.css';
import EngineeringTopics from './EngineeringTopics';

function App() {
  return (
    <div className="App">
      <EngineeringTopics />
    </div>
  );
}

export default App;